const groupingOptions = [
    { value: 'status', label: 'Status' },
    { value: 'user', label: 'User' },
    { value: 'priority', label: 'Priority' },
  ];

  const orderOptions = [
    { value: 'asc', label: 'Title' },
    { value: 'desc', label: 'Priority' },
  ];
  export {orderOptions,groupingOptions}